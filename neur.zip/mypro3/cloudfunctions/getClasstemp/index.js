// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})
const db = cloud.database()
const _ = db.command
const MAX_LIMIT = 100

var curDate = new Date();
var d = new Date();
var a = d.getDate();
var y = d.getFullYear();
var m = d.getMonth();


var dat =new Date(y, m, a, 0, 0, 0, 0);

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()

    // 先取出集合记录总数
    const countResult = await db.collection('Daily_Temperature').count()
    const total = countResult.total
    // 计算需分几次取
    const batchTimes = Math.ceil(total / 100)
    // 承载所有读操作的 promise 的数组
    const tasks = []
    for (let i = 0; i < batchTimes; i++) {
      const promise = db.collection('Daily_Temperature').skip(i * MAX_LIMIT).limit(MAX_LIMIT).where({
        date:_.gte(dat),
        id:_.in(event.id_one)
      }).get()
      tasks.push(promise)
    }
    // 等待所有
    return (await Promise.all(tasks)).reduce((acc, cur) => {
      return {
        data: acc.data.concat(cur.data),
        errMsg: acc.errMsg,
      }
    })
}