// 云函数入口文件
const cloud = require('wx-server-sdk')


cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

//读取公告数据
const db = cloud.database()
const _ = db.command


var d = new Date();
var a = d.getDate();
var y = d.getFullYear();
var m = d.getMonth();

if(a<7){
  if(m==1){
    y-=1;
    m=12;
    a = 31-7+a;
  }
}
var curDate =new Date(y, m, a-7, 0, 0, 0, 0);
// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()

  try{
    //Post
    return await db.collection('Post').where({
      publication_date:_.gte(curDate)
    }).get({
      success: function(res){
        console.log(res)
        return res
      }
    })
  }catch(e){
    console.log(e)
  }
}