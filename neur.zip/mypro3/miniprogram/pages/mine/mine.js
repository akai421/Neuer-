var app = getApp();

Page({
  	data: {
  		userInfo: {}
  	},
})