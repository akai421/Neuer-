// miniprogram/pages/mine/myInfo/changemyinfo/changemyinfo.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    openid:"123",
    name: "",//姓名
    sexarray: [' ', '男', '女'],//性别
    sexindex: 0,
    education: [' ', '高中', '本科', '研究生'],//学历
    eduindex: 0,
    typearray: ['学生', '班长', '导员'],
    typeindex: 0,
    number: "",//学号
    faculty: "",//学院
    major: "",
    classnum: "",
    roomnum: "",//寝室号
    phonenum: ""
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var getopenid = app.globalData.openid;
    var th = this;
    const db = wx.cloud.database();
    db.collection('UserInfo').where(
      { _openid: getopenid }
    ).get({
      // 找到记录集调用
      success: function (res) {
        //  将查询结果显示在页面上  
        th.setData({
          number: res.data[0]._id,
          name: res.data[0].name,
          sexindex: res.data[0].gender,//1表示男，2表示女
          eduindex: res.data[0].education,//1高中，2本科，3研究生
          faculty: res.data[0].faculty,//学院
          major: res.data[0].major,
          classnum: res.data[0].classnum,
          roomnum: res.data[0].department,//寝室号
          phonenum: res.data[0].phone,
          typeindex: res.data[0].type
        })
      },
      //  未查到数据时调用
      fail: function (res) {
        console.log(res.data);
        wx.showModal({
          title: '错误',
          content: '没有找到记录',
          showCancel: false
        })
      }
    })
    
  },
  changeinfo: function () {
    const db = wx.cloud.database()
    var sexindex = this.data.sexindex
    var eduindex = this.data.eduindex
    db.collection('UserInfo').doc(this.data.number).update({
      data: {
        name: this.data.name,
        gender: this.data.sexindex,
        education: this.data.eduindex,
        faculty: this.data.faculty,
        major: this.data.major,
        classnum: this.data.classnum,
        department: this.data.roomnum,
        phone: this.data.phonenum,
        type:this.data.typeindex
      },
      success: function (res) {
        console.log(res)
        wx.showModal({
          title: '成功',
          content: '修改成功',
          showCancel: false,
          success: function () {
            wx.redirectTo({
              url: '/pages/mine/myInfo/showmyinfo/showmyinfo',
            })
          },//然后将页面定位到showmyinfo列表
        })

      }
    })
  },
  bindKeyInputName: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  bindsexPickerChange: function (e) {
    console.log('bindsexPicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      sexindex: e.detail.value
    })
  },
  bindeduPickerChange: function (e) {
    console.log('bindeduPicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      eduindex: e.detail.value
    })
  },
  bindtypePickerChange: function (e) {
    console.log('bindtypePicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      typeindex: e.detail.value
    })
  },
  bindKeyInputNum: function (e) {
    this.setData({
      number: e.detail.value
    })
  },
  bindKeyFaculty: function (e) {
    this.setData({
      faculty: e.detail.value
    })
  },
  bindKeyMajor: function (e) {
    this.setData({
      major: e.detail.value
    })
  },
  bindKeyClass: function (e) {
    this.setData({
      classnum: e.detail.value
    })
  },
  bindKeyRoomnum: function (e) {
    this.setData({
      roomnum: e.detail.value
    })
  },
  bindKeyPhonenum: function (e) {
    this.setData({
      phonenum: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})