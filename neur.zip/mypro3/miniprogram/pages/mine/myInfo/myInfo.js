// pages/myTemperature/myTemperature.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: "",//姓名
    sexarray: [' ', '男', '女'],//性别
    sexindex: 0,
    education: [' ', '高中', '本科', '研究生'],//学历
    eduindex: 0,
    typearray: ['学生', '班长', '导员'],
    typeindex: 0,
    number: "",//学号
    faculty: "",//学院
    major:"",
    classnum: "",
    roomnum: "",//寝室号
    phonenum:"",
    address:""
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  addnewinfo: function () {
    const db = wx.cloud.database()
    var that = this
    var sexindex = that.data.sexindex
    var eduindex = that.data.eduindex
    try {
      if (that.data.typeindex == 1) {
        db.collection('Administrator').add({
          data: {
            _id: that.data.number,
            name: that.data.name,
            major: that.data.major,
            classnum: that.data.classnum,
            phoneNum: that.data.phonenum,
            type: 0 //这个地方0是指班长
          },
          success: function (res) {
            console.log(res)
          }
        })
        //  向test数据集添加记录
        db.collection('UserInfo').add({
          // data 字段表示需新增的 JSON 数据
          data: {
            _id: that.data.number,
            name: that.data.name,
            gender: that.data.sexindex,
            education: that.data.eduindex,
            type: that.data.typeindex,  //这个是userinfo表里的班长,和上面的表对应
            faculty: that.data.faculty,
            major: that.data.major,
            classnum: that.data.classnum,
            department: that.data.roomnum,
            phone: that.data.phonenum,
            address: that.data.address 
          },
          //  数据插入成功，调用该函数
          success: function (res) {
            console.log(res)
            wx.showModal({
              title: '成功',
              content: '上报成功',
              showCancel: false,
              success: function () {
                wx.navigateTo({
                  url: '/pages/mine/myInfo/showmyinfo/showmyinfo',
                })
              },//然后将页面转到showmyinfo里面去
            })
          }
        })
      } else if (that.data.typeindex == 2) {
        db.collection('Administrator').add({
          data: {
            _id: that.data.number,
            name: that.data.name,
            major: "",
            classnum: "",
            phoneNum: that.data.phonenum,
            type: 1 //这个位置是指导员
          },
          //  数据插入成功，调用该函数
          success: function (res) {
            console.log(res)
            wx.showModal({
              title: '成功',
              content: '上报成功',
              showCancel: false,
              success: function () {
                wx.navigateTo({
                  url: '/pages/mine/myInfo/showmyinfo/showmyinfo',
                })
              },//然后将页面转到showmyinfo里面去
            })
          }
        })
      }else{
        db.collection('UserInfo').add({
          // data 字段表示需新增的 JSON 数据
          data: {
            _id: that.data.number,
            name: that.data.name,
            gender: that.data.sexindex,
            education: that.data.eduindex,
            faculty: that.data.faculty,
            major: that.data.major,
            classnum: that.data.classnum,
            department: that.data.roomnum,
            phone: that.data.phonenum,
            address: that.data.address,
            type: that.data.typeindex  //这个是userinfo表里的班长，和上面的表对应
          },
          //  数据插入成功，调用该函数
          success: function (res) {
            console.log(res)
            wx.showModal({
              title: '成功',
              content: '上报成功',
              showCancel: false,
              success: function () {
                wx.navigateTo({
                  url: '/pages/mine/myInfo/showmyinfo/showmyinfo',
                })
              },//然后将页面转到showmyinfo里面去
            })
          }
        })
      }
    }
    catch (e) {
      wx.showModal({
        title: '错误',
        content: e.message,
        showCancel: false
      })
    }
  },
  bindKeyInputName: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  bindsexPickerChange: function (e) {
    console.log('bindsexPicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      sexindex: e.detail.value
    })
  },
  bindKeyAddress: function (e) {
    this.setData({
      address: e.detail.value
    })
  },
  bindeduPickerChange: function (e) {
    console.log('bindeduPicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      eduindex: e.detail.value
    })
  },
  bindtypePickerChange: function (e) {
    console.log('bindtypePicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      typeindex: e.detail.value
    })
  },
  
  bindKeyInputNum: function (e) {
    this.setData({
      number: e.detail.value
    })
  },
  bindKeyFaculty: function (e) {
    this.setData({
      faculty: e.detail.value
    })
  },
  bindKeyMajor: function (e) {
    this.setData({
      major: e.detail.value
    })
  },
  bindKeyClass: function (e) {
    this.setData({
      classnum: e.detail.value
    })
  },
  bindKeyRoomnum: function (e) {
    this.setData({
      roomnum: e.detail.value
    })
  },
  bindKeyPhonenum: function (e) {
    this.setData({
      phonenum: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})