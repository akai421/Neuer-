// miniprogram/pages/mine/myInfo/showmyinfo/showmyinfo.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    openid: "123",
    name: "",//姓名
    sexarray: [' ', '男', '女'],//性别
    sexindex: 0,
    education: [' ', '高中', '本科', '研究生'],//学历
    eduindex: 0,
    typearray: ['学生', '班长', '导员'],
    typeindex: 0,
    number: "",//学号
    faculty: "",//学院
    major: "",
    classnum: "",
    roomnum: "",//寝室号
    phonenum: "",
    address: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var getopenid = app.globalData.openid;
    var th = this;
    const db = wx.cloud.database()
    console.log(getopenid);
    //默认导员无法查看、修改个人信息
    db.collection('UserInfo').where(
      { _openid: getopenid }
    ).get({
      // 找到记录集调用
      success: function (res) {
        console.log(getopenid);
        //  将查询结果显示在页面上  
        if(res.data.length==0){//未查询到数据
          console.log("未查询到数据");
          wx.showModal({
            title: '提示',
            content: '请您先完善您的信息',
            success: function () {
              wx.redirectTo({
                url: '/pages/mine/myInfo/myInfo'
              })
            },//然后将页面转到我的问卷列表里面去
          })
        }else{//查询到数据
          console.log("查询到数据");
          th.setData({
            number: res.data[0]._id,
            name: res.data[0].name,
            sexindex: res.data[0].gender,//1表示男，2表示女
            eduindex: res.data[0].education,//1高中，2本科，3研究生
            faculty: res.data[0].faculty,//学院
            major: res.data[0].major,
            classnum: res.data[0].classnum,
            roomnum: res.data[0].department,//寝室号
            phonenum: res.data[0].phone,
            typeindex:res.data[0].type,
            address: res.data[0].address
          })
        } 
      },
    })
  },
  bindKeyInputName: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  bindsexPickerChange: function (e) {
    console.log('bindsexPicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      sexindex: e.detail.value
    })
  },
  bindeduPickerChange: function (e) {
    console.log('bindeduPicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      eduindex: e.detail.value
    })
  },
  bindtypePickerChange: function (e) {
    console.log('bindtypePicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      typeindex: e.detail.value
    })
  },
  bindKeyInputNum: function (e) {
    this.setData({
      number: e.detail.value
    })
  },
  bindKeyAddress: function (e) {
    this.setData({
      address: e.detail.value
    })
  },
  bindKeyFaculty: function (e) {
    this.setData({
      faculty: e.detail.value
    })
  },
  bindKeyMajor: function (e) {
    this.setData({
      major: e.detail.value
    })
  },
  bindKeyClass: function (e) {
    this.setData({
      classnum: e.detail.value
    })
  },
  bindKeyRoomnum: function (e) {
    this.setData({
      roomnum: e.detail.value
    })
  },
  bindKeyPhonenum: function (e) {
    this.setData({
      phonenum: e.detail.value
    })
  },
  gotochangeinfo: function () {
    wx.redirectTo({
      url: '/pages/mine/myInfo/changemyinfo/changemyinfo',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})