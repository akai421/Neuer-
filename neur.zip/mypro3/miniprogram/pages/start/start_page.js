// miniprogram/pages/start/start_page.js
import * as echarts from '../../ec-canvas/echarts.js';

const app = getApp();

let chart = null;
var data_list=[];
function initChart(canvas,width,height){
  var that = this
  chart = echarts.init(canvas,null,{
    width:width,
    height:height
  });
  canvas.setChart(chart);
  var options = {
    title: {
      text: '数据分布',
      x: 'left'
    },
    tooltip: {
      trigger: 'item',
      formatter: "{a} <br/>{b} : {c} ({d}%)"
    },
    color: ['#CD5C5C', '#00CED1', '#9ACD32', '#FFC0CB'],
    stillShowZeroSum: false,
    series: [
        {
          name: '数据分布',
          type: 'pie',
          radius: '40%',
          center: ['50%', '50%'],
          data: that.data_list,
          itemStyle: {
              emphasis: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(128, 128, 128, 0.5)'
              }
          }
        }
    ]
  };
  chart.setOption(options);
  return chart;
}

Page({

  /**
   * 页面的初始数据
   */
  data: {
    temperature:[453,22,18],
    imgUrls: [
      '../../images/swiper1.jpg',
      '../../images/swiper2.jpg',
      '../../images/swiper3.jpg'
    ],
    indicatorDots: true,
    vertical: false,
    circular:true,
    autoplay: true,
    interval: 3000,
    duration: 1200,
    all:550,
    iconArray: [
      {
          "iconUrl": '../../images/write.png',
          "iconText": '完善信息'
      },
      {
          "iconUrl": '../../images/temperature.png',
          "iconText": '每日体温'
      },
      {
          "iconUrl": '../../images/data.png',
          "iconText": '数据监测'
      },
      {
          "iconUrl": '../../images/quest.png',
          "iconText": '心理咨询'
      }
  ],
   
  ec:{
    lazyLoad: true, // 延迟加载
    //onInit:initChart
  },
    

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    this.echartsComponnet = this.selectComponent('#mychart-dom-pie');
    this.get_start_data()
    this.get_announce()
  },


  more:function(){
    wx.navigateTo({
      url: '../start/details/details',
    })
   
  },



  get_announce:function(){
    var that = this
    wx.cloud.callFunction({
      // 云函数名称
      name: 'announce',
      // 传给云函数的参数
  
      success: function(res) {
        
        console.log(res.result.data) // 3
        that.setData({
          announce : res.result.data,
          index:res.result.data.length
        })
        console.log(res.result.data.length)
      },
      fail: console.error
    })
  },
  get_start_data:function(){
    var that = this

    const db = wx.cloud.database();
    const _ = db.command;

    var all=0;
    db.collection("UserInfo").count({
      success:function(res){
        
        all = res.total;
        return res;
      }
    });
   
    //数字
    wx.cloud.callFunction({
      // 云函数名称
      name: 'start_data',
      // 传给云函数的参数
      success: res=> {
        console.log(res) // 3
        var normal=0,hot=0,innormal=0;

        var list = res.result.data
        var num = res.result.data.length
        for(var i=0;i<list.length;i++){
          console.log(i)
          if(list[i].temperature>37.1){
            hot=hot+1                      //发热
          }else if(list[i].temperature>36){
            normal=normal+1                   //正常
          }else{
            innormal=innormal+1
          }
        }
        data_list[0] = {value:normal,name:"正常"};
        data_list[1] = {value:hot,name:"发热"};
        data_list[2] = {value:all-num,name:"未报"};
        data_list[3] = {value:num,name:"已报"};

        this.setData({
      
          normal:normal,
          hot:hot,
          innormal:all-normal-hot
        })
        that.init_echarts()
        console.log(data_list)
      },
      fail:err=>{
        console.error
      } 
    })
  },
  init_echarts:function(){
  this.echartsComponnet.init((canvas, width, height) => {
    const chart = echarts.init(canvas,null,{
      width:width,
      height:height
    });
    canvas.setChart(chart);
    var options = {
      title: {
        text: '数据饼图',
        x: 'left'
      },
      tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b} : {c} ({d}%)"
      },
      color: ['#CD5C5C', '#00CED1', '#9ACD32', '#FFC0CB'],
      stillShowZeroSum: false,
      series: [
          {
            name: '数据饼图',
            type: 'pie',
            radius: '60%',
            center: ['50%', '50%'],
            data:data_list,
            itemStyle: {
                emphasis: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(128, 128, 128, 0.5)'
                }
            }
          }
      ]
    };
    chart.setOption(options);
    return chart;
  })
},

jump:function(e){
  console.log(e)
  if(e.currentTarget.dataset.index==0){
    wx.navigateTo({
      url: '../mine/myInfo/myInfo',
    })
  }else if(e.currentTarget.dataset.index==1){
    wx.navigateTo({
      url: '../questionnaire/quesdemo/quesdemo01/quesdemo01',
    })
  }else if(e.currentTarget.dataset.index==2){
    wx.navigateTo({
      url: '../start/details/details',
    })
  }else if(e.currentTarget.dataset.index==3){
    wx.navigateTo({
      url: '../user/use_protocol/use_protocol',
    })
  }
  
},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})