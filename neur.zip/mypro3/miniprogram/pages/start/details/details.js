
const app = getApp();
var unreportedList = [];
let reported_data = [];


Page({

  /**
   * 页面的初始数据
   */
  data: {
    //日期 时间
    todayDate: '',
    todayTime: '',
    get_date:'',
    //用户级别：教师 0 班长1 学生2
    userLevel:0,
    g_reply:false,
    c_reply:false,
    //年级已报 未报 正常 异常
    reported:543,
    unreported:1,
    normal:541,
    abnormal:2,
    //班级已报 未报 正常 异常
    c_reported: '-',
    c_unreported: '-',
    c_normal: '-',
    c_abnormal: '-',
    //年级未报人员名单
    unreportedList:[
      {"name":"张三","_id":"20170001","faculty":"软件工程","class":"1701"},
      {"name":"李四","_id":"20170041","faculty":"数字媒体","class":"1705"},
      {"name":"王五","_id":"20170031","faculty":"软件工程","class":"1703"},
      {"name":"毛六","_id":"20170021","faculty":"信息安全","class":"1704"},
    ],
    //年级异常人员名单
    abnormalList: [
      {"name":"张三","_id":"20170001","faculty":"软件工程","class":"1701"},
      {"name":"李四","_id":"20170041","faculty":"数字媒体","class":"1705"},
      {"name":"王五","_id":"20170031","faculty":"软件工程","class":"1703"},
      {"name":"毛六","_id":"20170021","faculty":"信息安全","class":"1704"},
    ],
    //班级未报人员名单
    c_unreportedList: [
      {"name":"张三","_id":"20170001"},
      {"name":"李四","_id":"20170041"},
      {"name":"王五","_id":"20170031"},
      {"name":"毛六","_id":"20170021"},
    ],
    //班级异常人员名单
    c_abnormalList: [
      
      {"name":"张三","_id":"20179001"},
      {"name":"李四","_id":"20170641"},
      {"name":"王五","_id":"20175031"},
      {"name":"毛六","_id":"20174021"},
    ],
    classIndex:0,
    classArray: ['请选择','软工一班', '软工二班', '软工三班', '软工四班', '软工五班', '软工六班', '软工七班', '软工八班', '软工九班', '信安一班', '信安二班', '信安三班', '数媒一班', '数媒二班', '软英一班', '软英二班','软日一班'],
    g_more:"查看更多",
    c_more:"查看更多"
  },

  getTime: function () {
    var date = new Date();
    var minute = date.getMinutes() >= 10 ? date.getMinutes() : ('0' + date.getMinutes());
    var hour = date.getHours() >= 10 ? date.getHours() : ('0' + date.getHours());
    var now = date.getDate() >= 10 ? date.getDate() : ('0' + date.getDate());
    var todayDate = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + now;
    var todayTime = hour + ':' + minute;
    this.setData({
      todayDate: todayDate,
      todayTime: todayTime
    })
  },

  changeClass:function(e){
    this.classIndex = e.detail.value;
    this.setData({
      classIndex:e.detail.value,

    })
  },

  
  g_findMore:function(){
    var that = this
    const db = wx.cloud.database();
    const _ = db.command;
    
    var openid = app.globalData.openid;
    console.log(openid)
    db.collection("Administrator").where({
      _openid:openid
    }).get({
      success:function(res){
         console.log(res)
        
        console.log(res.data[0].type)
        if (res.data[0].type==1) {
          
          that.setData({ 
            g_reply:~that.data.g_reply,
            g_more:~that.data.g_reply==false?"查看更多":"收起"
          })
        }
      }
    })

  },

  c_findMore: function () {
    var that = this
    const db = wx.cloud.database();
    const _ = db.command;
    
    //获得班长所在专业班级
    var openid = app.globalData.openid;
    db.collection("Administrator").where({
      _openid:openid
    }).get({
      success:function(res){
         console.log(res)
        

        if (res.data[0].type==0) {
          that.setData({ 
            c_reply: ~that.data.c_reply,
            c_more:~that.data.c_reply==false?"查看更多":"收起"
          })
        }
      }
    })
   
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getTime();
    this.get_grade_data();
    this.get_class_data();
  },

  get_grade_data:function(){
    var count = 0;
    var that = this
     //全年级总人数
     var total = 0;
     const db = wx.cloud.database();
     const _ = db.command;
     
     var res = db.collection("UserInfo").count({
       success:function(res){
         
         total = res.total;
         return res;
       }
     });
    
   //const countres = db.collection("UserInfo").count();
   //total = countres.total;
    var abnormal_list = [];
    var id = []
    wx.cloud.callFunction({
       // 云函数名称
       name: 'start_data',
       // 传给云函数的参数
       success: res=> {
 
         var list = res.result.data
         count= res.result.data.length
        

         var k=0,j=0;
         for(var i=0;i<list.length;i++){
    
          if(list[i].temperature>37.1){
            id[k] = list[i].id;
            k+=1;
          }
          reported_data[j]=list[i].id; 
          j+=1;                 
        }
        wx.cloud.callFunction({
          name:"getUserInfo",
          data:{
            id:id
          },
          success:function(res){
            that.setData({
              abnormalList:res.result.data,
            })
          }
        })
        
        
        
        if(count<total){
          wx.cloud.callFunction({
            name:"grade_data",
            data:{
              normal:reported_data             //已报数据
            },
            success:function(res){
              console.log(res) // 3
     
              var list = res.result.data
              //count= res.result.data.length
             
              that.setData({
                unreportedList:list,
              })
            }
          })
        }else{
          //无未报人数
          this.setData({
            unreportedList:[]
          })
        }

        that.setData({
          abnormal:k,
          reported:count,
          normal:count - k,
          unreported:total- count,          
        })
      }

    })
  },

  //如果考虑多个学院使用
  get_faculty:function(){

    var openid = app.globalData.openid;

    const db = wx.cloud.database();
    const _ = db.command;
    //查询当前访问导员的学院
    const res = db.collection("导员表").where({
      _openid:openid
    }).get()
  },

  get_class_data:function(){
    var that = this;
    var openid = app.globalData.openid;

     //某班级
     var total = 0;
     const db = wx.cloud.database();
     const _ = db.command;
     var major = "软件工程";
     var the_class = "1701";
     //获得班长所在专业班级
     db.collection("UserInfo").where({
       _openid:openid
     }).get({
       success:function(res){
          console.log(res)
        
          major = res.data.major;
          the_class = res.data.class;
       }
     })
    
    
    
    var abnormal_list = [];
    
    //
    

    
    wx.cloud.callFunction({
      name:"getClassdata",
      data:{
        major:major,
        class:the_class
      },
      success:function(res){
        console.log(res) // 3
        
        //班级人数列表
        var list1 = res.result.data
        //班级总人数
        total= res.result.data.length
        
        var id_one = []
        for(var i=0;i<list1.length;i++){
          id_one[i] = list1[i]._id;
        }
       

        wx.cloud.callFunction({
          name:"getClasstemp",
          data:{
            id_one:id_one
          },
       
          success:function(res){
            
            console.log(res)
            //已报人数
            var c_reported = res.result.data.length;
            //已经报人列表
            var list_one = res.result.data;
        
            var k=0;
            for(var i=0;i<list_one.length;i++){
             
              if(list_one[i].temperature>37.1){
                var item;
                for(var s=0;s<list1.length;s++){
                  if(list1[s]._id==list_one[i].id){
                    item = list1[s];
                    break;
                  }
                }
                abnormal_list[k] = item;
                k+=1;
              }
            }

            var list_one_id = [];
           
            for(var z=0;z<list_one.length;z++){
              list_one_id[z] = list_one[z].id; 
            }
          
            var unreported_list = []
            var m=0,x=1;
            for(var j=0;j<list1.length;j++){
             
              for(var it=0;it<list_one_id.length;it++){
                if(list1[j]._id == list_one_id[it]){
                  x = 0;
                  break;
                }
              }
              if(x==1){
                unreported_list[m] = list1[j];
                m+=1
              }else{
                x = 1;
              }
              
            }
            
            that.setData({
              c_unreportedList:unreported_list,
              c_abnormalList:abnormal_list,
              c_reported:c_reported,
              c_normal:c_reported-k,
              c_abnormal:k,
              c_unreported:m, 
            })

          }
        })
       
      }
    })
  
  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})