// pages/questionnaire/showmyques/showmyques01/showmyques01.js
var app = getApp();
var util=require("../../../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    number:"",
    temp:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var th=this;
    var getopenid = app.globalData.openid;
    let curDate = new Date();
    const db = wx.cloud.database()
    const com = db.command
    var nowaday = th.getTodaytime(curDate);
    console.log(nowaday);
    //根据openid获得学号
    db.collection('UserInfo').where({
        _openid: getopenid
      }).get({
      // 找到记录集调用
      success: function (res) {
        th.setData({
          number: res.data[0]._id,
        })
        db.collection('Daily_Temperature').where({
          id: th.data.number,
          date: com.gte(nowaday)
        }).get({
          // 找到记录集调用
          success: function (res) {
            //  将查询结果显示在页面上 
            if (res.data.length == 0) {
              console.log("未查找到体温记录");
            } else {
              console.log("查找到体温记录", th.data.number);
              th.setData({
                temp: res.data[0].temperature
              })
            }
          },
          //  未查到数据时调用
        })
      },
    })
  },
  //得到当天凌晨的标准时间
  getTodaytime:function(time){
    var todaytime="";
    var _hour = "00";
    var _minute = "00";
    var _second = "00";
    var _year = time.getFullYear()
    var _month = time.getMonth()+1;
    var _date = time.getDate();
    todaytime = _year + "-" + _month + "-" + _date + " " + _hour + ":" + _minute + ":" +_second;
    var fomatdate = new Date(todaytime).getTime();
    return new Date(fomatdate)
  },
  gotochangemytemp: function () {
    wx.navigateTo({
      url: '/pages/questionnaire/editmyques/editques01/editques01',
    })
  },
})