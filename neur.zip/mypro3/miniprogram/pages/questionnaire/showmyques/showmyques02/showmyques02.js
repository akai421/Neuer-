// pages/questionnaire/showmyques/showmyques02/showmyques02.js
var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    name: "",//姓名
    sexarray: [' ', '男', '女'],//性别
    sexindex: 0,
    education: [' ', '高中', '本科', '研究生'],//学历
    eduindex: 0,
    number: "",//学号
    origin: "",//生源地
    sphonenum: "",//学生联系电话
    fphonenum: "",//家长联系电话
    visit: "",//寒假去向及到访地
    sightnum: "",//寒假返校乘坐车次及座位号
    instructor: "",//辅导员
    roomnum: "",//寝室号
    isgotoEpidemic: [' ', '是', '否'],//是否前往疫区
    isgotoindex: 0,
    isFever: [' ', '是', '否'],//是否有发烧、咳嗽、感染病毒症状
    isFeverindex: 0,
    isInfection: [' ', '是', '否'],//家庭是否有人感染病毒
    isInfecindex: 0,
    awaydate: "2019-09-01",//离校时间
    backdate: "2019-09-01",//返校时间
    temperature: "",//入寝前测温情况
    remark: ""//备注
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var th = this;
    const db = wx.cloud.database()
    var getopenid = app.globalData.openid;
    //根据openid获得学号
    db.collection('UserInfo').where({
      _openid: getopenid
    }).get({
      // 找到记录集调用
      success: function (res) {
        console.log(getopenid);
        th.setData({
          number: res.data[0]._id,
        })
        db.collection('que_4').doc(th.data.number).get({
          // 找到记录集调用
          success: function (res) {
            //  将查询结果显示在页面上  
            th.setData({
              number: res.data._id,
              name: res.data.name,
              sexindex: res.data.gender,
              eduindex: res.data.education,
              origin: res.data.address,
              sphonenum: res.data.stuPhone,
              fphonenum: res.data.parentNum,
              visit: res.data.visitPlace,
              awaydate: res.data.leaveTime,
              backdate: res.data.backTime,
              sightnum: res.data.trafficInfo,
              instructor: res.data.tutor,
              roomnum: res.data.department,
              isgotoindex: res.data.que01,
              isFeverindex: res.data.que02,
              isInfecindex: res.data.que03,
              temperature: res.data.temperature,
              remark: res.data.remark
            })
          },
          //  未查到数据时调用
          fail: function (res) {
            console.log(res.data);
            wx.showModal({
              title: '错误',
              content: '没有找到记录',
              showCancel: false,
              success: function () {
                wx.redirectTo({
                  url: '/pages/questionnaire/quesdemo/quesdemo02/quesdemo02'
                })
              },//然后将页面转到我的问卷列表里面去
            })
          }
        })
      },
    })
  },
  //下面是对文本框值变化做出的反应
  bindKeyInputName: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  bindsexPickerChange: function (e) {
    this.setData({
      sexindex: e.detail.value
    })
  },
  bindeduPickerChange: function (e) {
    this.setData({
      eduindex: e.detail.value
    })
  },
  bindKeyInputNum: function (e) {
    this.setData({
      number: e.detail.value
    })
  },
  bindKeyOrigin: function (e) {
    this.setData({
      origin: e.detail.value
    })
  },
  bindKeySphonenum: function (e) {
    this.setData({
      sphonenum: e.detail.value
    })
  },
  bindKeyFphonenum: function (e) {
    this.setData({
      fphonenum: e.detail.value
    })
  },
  bindKeyVisit: function (e) {
    this.setData({
      visit: e.detail.value
    })
  },
  bindKeySightnum: function (e) {
    this.setData({
      sightnum: e.detail.value
    })
  },
  bindKeyInstructor: function (e) {
    this.setData({
      instructor: e.detail.value
    })
  },
  bindKeyRoomnum: function (e) {
    this.setData({
      roomnum: e.detail.value
    })
  },
  bindisgotoPickerChange: function (e) {
    this.setData({
      isgotoindex: e.detail.value
    })
  },
  bindisFeverPickerChange: function (e) {
    this.setData({
      isFeverindex: e.detail.value
    })
  },
  bindisInfecPickerChange: function (e) {
    this.setData({
      isInfecindex: e.detail.value
    })
  },
  bindawayDateChange: function (e) {
    this.setData({
      awaydate: e.detail.value
    })
  },
  bindbackDateChange: function (e) {
    this.setData({
      backdate: e.detail.value
    })
  },
  bindKeyTemperature: function (e) {
    this.setData({
      temperature: e.detail.value
    })
  },
  bindKeyRemark: function (e) {
    this.setData({
      remark: e.detail.value
    })
  },
  gotochangemyinfo: function () {
    wx.redirectTo({
      url: '/pages/questionnaire/editmyques/editques02/editques02',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})