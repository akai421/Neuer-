// pages/questionnaire/editmyques/editques01/editques01.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    number:'20170001',
    temp: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  changemytemp: function () {
    const db = wx.cloud.database()
    var changetemp = this.data.temp
    console.log(this.data.number)
    db.collection('test').doc(this.data.number).update({
      data: {
        temperature:18
      }, 
      success:function (res) {
        console.log(changetemp)
        console.log(res)
        console.log(res.data)
        wx.showModal({
          title: '成功',
          content: '成功修改体温',
          showCancel: false,
          success: function () {
            wx.navigateTo({
              url: '/pages/mian/mian',
            })
          },//然后将页面定位到我的问卷列表
        })
      }
      
      /*success: res => {
        console.log(res.data)
        wx.showToast({
          title: '修改记录成功',
        })
      }, fail: err => {
        wx.showToast({
          title: '修改失败',
        })
      }*/
    })
  },
  bindKeychangeTemp:function (e) {
    this.setData({
      temp: e.detail.value
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})