Page({
  /**
   * 页面的初始数据
   */
  data: {
    currentIndex: 0,
    ongoingList: [{'name':'','time':''}],
    endList: [],
  },

  onLoad:function(options){
    const db = wx.cloud.database()
    const que_name = db.collection('que_name')
    //进行中 -> ongoingList
    que_name.where({
      state:true
    })
      .get({
        success: res => {
          console.log(res.data)
          this.setData({
            ongoingList: res.data
          })
        }
      })
    //已结束 -> endList
    que_name.where({
      state: false
    })
      .get({
        success: res => {
          console.log(res.data)
          this.setData({
            endList: res.data
          })
        }
      })
    
    //que_name表 add实现
    // var date = new Date();
    // var now = date.getDate() >= 10 ? date.getDate() : ('0' + date.getDate());
    // var todayDate = date.getFullYear() + '/' + (date.getMonth() + 1) + '/' + now;
    // que_name.add({
    //   data:{
    //     _id:3,
    //     name:'网课信息收集',
    //     time:todayDate,
    //     state:true
    //   },
    //   success: function (res) {
    //     // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
    //     console.log(res)
    //   }
    // })
  },
  jump: function (e) {
    console.log(e.currentTarget.dataset)
    if (e.currentTarget.dataset.index == 0) {
      wx.navigateTo({
        url: '../questionnaire/quesdemo/quesdemo01/quesdemo01',
      })
    } else if (e.currentTarget.dataset.index == 1) {
      wx.navigateTo({
        url: '../questionnaire/quesdemo/quesdemo02/quesdemo02',
      })
    } else if (e.currentTarget.dataset.index == 2) {
      wx.navigateTo({
        url: '../questionnaire/quesdemo/quesdemo02/quesdemo02',
      })
    }

  },
  //swiper切换时会调用
  pagechange: function (e) {
    if ("touch" === e.detail.source) {
      let currentPageIndex = this.data.currentIndex
      currentPageIndex = (currentPageIndex + 1) % 2
      this.setData({
        currentIndex: currentIndex
      })
    }
  },

  //用户点击tab时调用
  titleClick: function (e) {
    let currentPageIndex =
      this.setData({
        //拿到当前索引并动态改变
        currentIndex: e.currentTarget.dataset.idx
      })
  }
})
