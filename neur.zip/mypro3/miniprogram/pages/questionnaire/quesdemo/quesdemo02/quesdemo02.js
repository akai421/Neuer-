// pages/questionnaire/quesdemo/quesdemo02/quesdemo02.js
var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    que_name: '东北大学软件学院新型冠状病毒感染肺炎疫情防控信息统计表',
    que_num: 4,
    name:"",//姓名
    sexarray: [' ','男', '女'],//性别
    sexindex: 0,
    education: [' ', '高中', '本科', '研究生'],//学历
    eduindex:0,
    number:"",//学号
    origin:"",//生源地
    sphonenum:"",//学生联系电话
    fphonenum: "",//家长联系电话
    visit:"",//寒假去向及到访地
    sightnum:"",//寒假返校乘坐车次及座位号
    instructor:"",//辅导员
    roomnum:"",//寝室号
    isgotoEpidemic:[' ','是','否'],//是否前往疫区
    isgotoindex: 0,
    isFever: [' ', '是', '否'],//是否有发烧、咳嗽、感染病毒症状
    isFeverindex: 0,
    isInfection: [' ', '是', '否'],//家庭是否有人感染病毒
    isInfecindex: 0,
    awaydate: "2019-09-01",//离校时间
    backdate: "2019-09-01",//返校时间
    temperature:"",//入寝前测温情况
    remark:""//备注
  },
  onLoad: function (options) {
    //首先查询数据库是否已经录入信息，如果录入则直接跳转到显示页面
    var th = this;
    var getopenid = app.globalData.openid;
    let curDate = new Date();
    const db = wx.cloud.database()
    const com = db.command
    //根据openid获得学号
    db.collection('UserInfo').where({
      _openid: getopenid
    }).get({
      // 找到记录集调用
      success: function (res) {
        console.log(getopenid);
        th.setData({
          number: res.data[0]._id,
        })
      },
    })
    db.collection('que_4').where({
      _id: th.data.number
    }).get({
      // 找到记录集调用
      success: function (res) {
        if (res.data.length == 0) {//  未查到数据时调用
          console.log("开始输入防疫信息问卷");
        } else {
          wx.redirectTo({
            url: '/pages/questionnaire/showmyques/showmyques02/showmyques02',
          })
        }
      },
    })
  },
  addnewrecord:function(){
    const db = wx.cloud.database()
    var that = this
    var sexindex = this.data.sexindex
    var eduindex = this.data.eduindex
    var isgotoindex = this.data.isgotoindex
    var isFeverindex = this.data.isFeverindex
    var isInfecindex = this.data.isInfecindex
    try {
      //  向que_4数据集添加记录
      db.collection('que_4').add({
        // data 字段表示需新增的 JSON 数据
        data: {
          _id: this.data.number,
          name:this.data.name,
          gender: this.data.sexindex,
          education:this.data.eduindex,
          address:this.data.origin,
          stuPhone:this.data.sphonenum,
          parentNum: this.data.fphonenum,
          visitPlace:this.data.visit,
          leaveTime:this.data.awaydate,
          backTime:this.data.backdate,
          trafficInfo: this.data.sightnum,
          tutor:this.data.instructor,
          department:this.data.roomnum,
          que01:this.data.isgotoindex,
          que02:this.data.isFeverindex,
          que03:this.data.isInfecindex,
          temperature: this.data.temperature,
          remark:this.data.remark
        },
        //  数据插入成功，调用该函数
        success: function (res) {
          console.log(res)
          //向问卷填写日志添加填写记录
          db.collection('ques_log').add({
            // data 字段表示需新增的 JSON 数据
            data: {
              number: that.data.number,
              time: db.serverDate(),
              que_name: that.data.que_name,
              que_num: that.data.que_num

            },
            //  数据插入成功，调用该函数
            success: function (res) {
              console.log("问卷填写日志：", res)
            }
          })
          wx.showModal({
            title: '成功',
            content: '上报成功',
            showCancel: false,
            success: function () {
              wx.redirectTo({
                url: '/pages/questionnaire/showmyques/showmyques02/showmyques02',
              })
            },//然后将页面转到显示列表里面去
          })
          

        }
      })
    }
    catch (e) {
      wx.showModal({
        title: '错误',
        content: e.message,
        showCancel: false
      })
    }
  },

  //下面是对文本框值变化做出的反应
  bindKeyInputName: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  bindsexPickerChange: function (e) {
    console.log('bindsexPicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      sexindex: e.detail.value
    })
  },
  bindeduPickerChange: function (e) {
    console.log('bindeduPicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      eduindex: e.detail.value
    })
  },
  bindKeyInputNum: function (e) {
    this.setData({
      number: e.detail.value
    })
  },
  bindKeyOrigin: function (e) {
    this.setData({
      origin: e.detail.value
    })
  },
  bindKeySphonenum: function(e) {
    this.setData({
      sphonenum: e.detail.value
    })
  },
  bindKeyFphonenum: function (e) {
    this.setData({
      fphonenum: e.detail.value
    })
  },
  bindKeyVisit: function (e) {
    this.setData({
      visit: e.detail.value
    })
  },
  bindKeySightnum: function(e) {
    this.setData({
      sightnum: e.detail.value
    })
  },
  bindKeyInstructor: function(e) {
    this.setData({
      instructor: e.detail.value
    })
  },
  bindKeyRoomnum: function (e) {
    this.setData({
      roomnum: e.detail.value
    })
  },
  bindisgotoPickerChange: function (e) {
    console.log('bindisgotoPicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      isgotoindex: e.detail.value
    })
  },
  bindisFeverPickerChange: function (e) {
    console.log('bindisFeverPicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      isFeverindex: e.detail.value
    })
  },
  bindisInfecPickerChange: function (e) {
    console.log('bindisInfecPicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      isInfecindex: e.detail.value
    })
  },
  bindawayDateChange: function (e) {
    this.setData({
      awaydate: e.detail.value
    })
  },
  bindbackDateChange: function (e) {
    this.setData({
      backdate: e.detail.value
    })
  },
  bindKeyTemperature: function (e) {
    this.setData({
      temperature: e.detail.value
    })
  },
  bindKeyRemark: function (e) {
    this.setData({
      remark: e.detail.value
    })
  },
})