// pages/questionnaire/quesdemo/quesdemo01/quesdemo01.js
var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    number: '',
    temp: '',
    que_name:'每日一报',
    que_num:1
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //首先查询数据库是否已经录入体温，如果录入则直接跳转到显示页面
    var th = this;
    var getopenid = app.globalData.openid;
    let curDate = new Date();
    const db = wx.cloud.database()
    const com = db.command
    var nowaday = th.getTodaytime(curDate);
    console.log(nowaday);
    //根据openid获得学号
    db.collection('UserInfo').where({
      _openid: getopenid
    }).get({
      // 找到记录集调用
      success: function (res) {
        console.log(getopenid);
        th.setData({
          number: res.data[0]._id,
        })
      },
    })
    db.collection('Daily_Temperature').where({
      id: th.data.number,
      date: com.gte(nowaday)
    }).get({
      // 找到记录集调用
      success: function (res) {
        if (res.data.length == 0) {//  未查到数据时调用
          console.log("开始输入每日一报调查问卷");
        }else{
          wx.redirectTo({
            url: '/pages/questionnaire/showmyques/showmyques01/showmyques01',
          })
        }
      },
    })
  },
  //得到当天凌晨的标准时间
  getTodaytime: function (time) {
    var todaytime = "";
    var _hour = "00";
    var _minute = "00";
    var _second = "00";
    var _year = time.getFullYear()
    var _month = time.getMonth() + 1;
    var _date = time.getDate();
    todaytime = _year + "-" + _month + "-" + _date + " " + _hour + ":" + _minute + ":" + _second;
    var fomatdate = new Date(todaytime).getTime();
    return new Date(fomatdate)
  },
  insertMyTemp:function() {
    const db = wx.cloud.database()
    var that = this
    var getopenid = app.globalData.openid;
    try {
      //  将年龄转换为整数类型值
      var mytemp = that.data.temp
      //  如果输入的年龄不是数字，会显示错误对话框，并退出该函数
      if (isNaN(mytemp)) {
        //  显示错误对话框
        wx.showModal({
          title: '错误',
          content: '请输入正确的体温',
          showCancel: false
        })
        return
      }
      //  向test数据集添加记录
      db.collection('Daily_Temperature').add({
        // data 字段表示需新增的 JSON 数据
        data: {
          id: that.data.number,
          date: db.serverDate(),
          temperature: that.data.temp
        },
        //  数据插入成功，调用该函数
        success: function (res) {
          console.log("每日一报：",res)
          //向问卷填写日志添加填写记录
          db.collection('ques_log').add({
            // data 字段表示需新增的 JSON 数据
            data: {
              number: that.data.number,
              time: db.serverDate(),
              que_name: that.data.que_name,
              que_num: that.data.que_num

            },
            //  数据插入成功，调用该函数
            success: function (res) {
              console.log("问卷填写日志：",res)
            }
          })
          wx.showModal({
            title: '成功',
            content: '成功插入记录',
            showCancel: false,
            success: function () {
              wx.redirectTo({
                url: '/pages/questionnaire/showmyques/showmyques01/showmyques01',
              })
            },//然后将页面定位到显示界面
          })
        }
      })
    }
    catch (e) {
      wx.showModal({
        title: '错误',
        content: e.message,
        showCancel: false
      })
    }
  },

  bindKeyNumber: function (e) {
    this.setData({
      number: e.detail.value
    })
  },
  bindKeyTemp: function (e) {
    this.setData({
      temp: e.detail.value
    })
  }
})